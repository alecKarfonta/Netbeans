package siggrabber;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.IOException;
import java.util.ArrayList;

public class LineTools {
    
    private static Color searchColor = Color.WHITE;
    private static int lineLengthThreshold = 50;
    static int maxColorDifference = 5000000;
    
    public static ArrayList getLines (BufferedImage image) {
        ArrayList<Line> lines = new ArrayList<Line>();
        ArrayList<Line> linesInAllRows = getHorizLines(image);
        ArrayList<Line> linesInAllCols = getVertLines(image);
        
        // add each line in each row and column to one large list of lines
        for (Line line : linesInAllRows ) {
            lines.add(line);
        }
        for (Line line : linesInAllCols ) {
            lines.add(line);
        }
        
        return lines;
    }
    
    public static ArrayList getHorizLines(BufferedImage image) {
        return getHorizLines(image,0,image.getHeight());
    }
    
    public static ArrayList getHorizLines(BufferedImage image, int startY, int endY) {
        ArrayList<Line> linesInAllRows = new ArrayList<Line>();
        ArrayList<Line> linesInRow = null;
        int y = startY - 1;     
        while(++y < image.getHeight()) {
            linesInRow = getLinesInRow(image, 0, y);
            for (int index = 0; index < linesInRow.size(); index++) {
                linesInAllRows.add(linesInRow.get(index));
            }
        }
        
        return linesInAllRows;
    }
    
    public static ArrayList getVertLines(BufferedImage image) {
        return getVertLines(image,0,image.getWidth());
    }
    
    public static ArrayList getVertLines(BufferedImage image, int startX, int endX) {
        ArrayList<Line> linesInCol = null;
        ArrayList<Line> linesInAllCols = new ArrayList<Line>();
        int x = startX - 1;
        while (++x < endX) {
            linesInCol = getLinesInCol(image, x, 0);
            for (int index = 0; index < linesInCol.size(); index++) {
                linesInAllCols.add(linesInCol.get(index));
            }
        }
        return linesInAllCols;
    }
    
    private static ArrayList getLinesInRow(BufferedImage image, int startX, int y) {
        int lineThreshold = lineLengthThreshold;  
        ArrayList<Line> lines = new ArrayList<Line>();
        Point startPoint = null, endPoint = null;
        
        // for each x after the start x and before the end
        for (int x = startX; x < image.getWidth(); x++) {
            // if the pixel was black
            if (getColorDifference(image.getRGB(x, y), searchColor.getRGB()) < maxColorDifference) {
                // if its not at the edge of the image
                if ((x+5) < image.getWidth()) {
                    // if 1 of 5 colors match the first color
                    if (isColorMatch(image.getRGB(x, y), image.getRGB(x+1, y), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x+2, y), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x+3, y), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x+4, y), maxColorDifference)) {
                        startPoint = new Point(x, y);
                        /**/
                        while ((x+5) < image.getWidth()) {
                            if (isColorMatch(image.getRGB(x, y), image.getRGB(x+1, y), maxColorDifference)) {
                                x+=1;
                            }
                            else if (isColorMatch(image.getRGB(x, y), image.getRGB(x+2, y), maxColorDifference)) {
                                x+=2;
                            }
                            else if (isColorMatch(image.getRGB(x, y), image.getRGB(x+3, y), maxColorDifference)) {
                                x+=3;
                            }
                            else if (isColorMatch(image.getRGB(x, y), image.getRGB(x+4, y), maxColorDifference)) {
                                x+=4;
                            }
                            else {
                                break;
                            }
                        
                        }
                        /**/
                        endPoint = new Point(x, y);
                        
                        // if the length of the line was above the line threshold
                        if ((endPoint.getX() - startPoint.getX()) > lineThreshold) {
                            // add the line
                            Point[] points = {startPoint, endPoint};
                            lines.add(new Line(points));
                        }
                    }
                }
            }
        }
        
        return lines;
    }
    
    private static ArrayList getLinesInCol(BufferedImage image, int x, int startY) {
        int lineThreshold = lineLengthThreshold;
        ArrayList<Line> lines = new ArrayList<Line>();
        Point startPoint = null, endPoint = null;
        /**/
        // for each y after the start y and before the bottom
        for (int y = startY; y < image.getHeight(); y++) {
            // if the pixel was black
            /**/
            if (getColorDifference(image.getRGB(x, y), searchColor.getRGB()) < maxColorDifference) {
                    // if 1 of 5 colors match the first color
                    if (((y+5) < image.getHeight())
                            && (
                               isColorMatch(image.getRGB(x, y), image.getRGB(x, y+1), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+2), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+3), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+4), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+5), maxColorDifference))
                                ){
                        startPoint = new Point(x, y);
                        /**/
                        while (((y+5) < image.getHeight())
                            && (
                               isColorMatch(image.getRGB(x, y), image.getRGB(x, y+1), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+2), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+3), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+4), maxColorDifference)
                            || isColorMatch(image.getRGB(x, y), image.getRGB(x, y+5), maxColorDifference))
                                ) {
                            y++;
                        }
                        /**/
                        endPoint = new Point(x, y);
                        
                        // if the length of the line was above the line threshold
                        if ((endPoint.getY() - startPoint.getY()) > lineThreshold) {
                            // add the line
                            Point[] points = {startPoint, endPoint};
                            lines.add(new Line(points));
                        }
                    }
            }
            /**/
        }
        /**/
        
        return lines;
    }
    
    private static int getIndexOfLongestLine(ArrayList<Line> lines) {
        int indexOfMax = 0;
        for (int index = 0; index < lines.size(); index++) {
            if (lines.get(index).getLength() > lines.get(indexOfMax).getLength()) {
                indexOfMax = index;
            }
        }
        
        return 1;
        
    }
    
    
    private static int getColorDifference(int color1, int color2) {
        if (-color1 > -color2) {
            //System.out.println(-color1 - -color2);
            return -color1 - -color2;
        }
        else
        {
            //System.out.println(-color2 - -color1);
            return -color2 - -color1;
        }
    }
    
    private static boolean isColorMatch(int color1, int color2, int range) {
        
        if (getColorDifference(color1, color2) < range) {
            return true;
        }
        else {
            return false;
        }
    }
    
    private static byte[] getByteArray (BufferedImage image) throws IOException {
        
        // get DataBufferBytes from Raster
        WritableRaster raster = image.getRaster();
        DataBufferByte data   = (DataBufferByte) raster.getDataBuffer();
        return ( data.getData() );
    }
    
}
