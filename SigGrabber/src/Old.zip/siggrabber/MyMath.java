package siggrabber;


public class MyMath {
    public static double[] polToRect(double rho, double theta) {
        return new double[] {rho * Math.cos(theta), rho * Math.sin(theta)};
    }
    
}
