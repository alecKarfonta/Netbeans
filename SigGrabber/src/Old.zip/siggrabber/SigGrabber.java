
package siggrabber;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class SigGrabber {
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        // declare the gui components
        JFrame frame = GeneralTools.createFrame("SigGrabber");
        ArrayList<jpLine> jpLinesArray = new ArrayList<jpLine>();
        JScrollPane jspOrig, jspProc, jspLines;
        JPanel jpOrig = new JPanel();
        JPanel jpProc = new JPanel();
        JPanel jpLines = new JPanel();
        
        String folderName = "images";
        String[] files = GeneralTools.getFileNames(folderName);
        ArrayList<String> jpgs = new ArrayList<String>();
        ArrayList<BufferedImage> origImages = new ArrayList<BufferedImage>();
        ArrayList<BufferedImage> procImages = new ArrayList<BufferedImage>();
        
        frame.setLayout(new BorderLayout());
        jpOrig.setLayout(new GridLayout(0,1));
        jpProc.setLayout(new GridLayout(0,1));
        jpLines.setLayout(new GridLayout(0,1));
        
        //create the detector
        CannyEdgeDetector detector = new CannyEdgeDetector();

        //adjust its parameters as desired
        detector.setLowThreshold(0.5f);
        detector.setHighThreshold(1f);

        int index;
        
        // find the jpgs in the folder
        for (index = 0; index < files.length; index++) {
            if (files[index].contains(".jpg"))
                jpgs.add(files[index]);
        }
        
        // edge and threshold the images
        for (index = 0; index < jpgs.size(); index++) {
            System.out.println(folderName + "/" + jpgs.get(index));
          
            origImages.add(ImageIO.read(new File(folderName+ "/" + jpgs.get(index))));
            
            if (origImages.get(index) != null) {
                origImages.set(index, ImageTools.getCroppedImage(origImages.get(index)));
                jpOrig.add(new JLabel(new ImageIcon(origImages.get(index))));
                //apply it to an image
                detector.setSourceImage(origImages.get(index));
                detector.process();
                procImages.add(detector.getEdgesImage());
                jpProc.add(new JLabel(new ImageIcon(procImages.get(index))));
            }
        }
        ArrayList<ArrayList<Line>> lines = new ArrayList<ArrayList<Line>>();
        
        // get the lines out of each processed image
        for (index = 0; index < procImages.size(); index++) {
            lines.add(LineTools.getLines(procImages.get(index)));
            
            jpLinesArray.add(new jpLine(lines.get(index)));
            jpLinesArray.get(index)
                    .setPreferredSize(new Dimension(procImages.get(index).getWidth()
                                                    , procImages.get(index).getHeight()));
            
            jpLines.add(jpLinesArray.get(index));
        }
        
        jspLines = new JScrollPane(jpLines);
        jspLines.createVerticalScrollBar();
        
        jspOrig = new JScrollPane(jpOrig);
        jspOrig.createVerticalScrollBar();
        
        jspProc = new JScrollPane(jpProc);
        jspProc.createVerticalScrollBar();
        
        
        frame.add(jspOrig, BorderLayout.WEST);
        //frame.add(jspProc);
        frame.add(jspLines, BorderLayout.EAST);
        
        frame.pack();
        frame.setVisible(true);
        
        
        
        
        /**
        
        
        JFrame frame = GeneralTools.createFrame("sigGrabber");
        BufferedImage origImage = ImageIO.read(new File("images/trav.jpg"));
        //BufferedImage threshImage; 
        //travCheckImage = ImageTools.getGrayscale(travCheckImage);
        //threshImage = ImageTools.Threshold(origImage, 120);

        origImage = ImageTools.getCroppedImage(origImage);

        //create the detector
        CannyEdgeDetector detector = new CannyEdgeDetector();

        //adjust its parameters as desired
        detector.setLowThreshold(0.5f);
        detector.setHighThreshold(1f);

        //apply it to an image
        detector.setSourceImage(origImage);
        detector.process();
        BufferedImage edgedImage = detector.getEdgesImage();

        // Hough Transform
        ArrayList<HoughPoint> AccumulatorMatrix = new ArrayList<HoughPoint>();
        DecimalFormat sigFig = new DecimalFormat("#.#");
        boolean isNewHoughPoint = true;
        double rho = 0;

        for (int x = 0; x < 200; x++) {
            for (int y = 0; y < 20; y++) {
                // if the pixel was white
                if (ImageTools.isColorMatch(image.getRGB(x, y), Color.WHITE.getRGB(), 100)) {
                    // for each degree from -90 to 90
                    for (int theta = -90; theta < 90; theta++ ) {
                        // calculate rho to two decimal places
                        rho = x * Math.cos(theta) + y * Math.sin(theta);
                        rho = Double.parseDouble(sigFig.format(rho));
                        // check if (rho,theta) already exists in the AccumulatorMatrix
                        for(HoughPoint hp : AccumulatorMatrix) {
                            // if the HoughPoint already exists
                            if (hp.getTheta() == theta && hp.getRho() == rho) {
                                isNewHoughPoint = false;
                                // increment it's value
                                hp.incrementValue();
                            }
                        }
                        // if the HoughPoint was new
                        if (isNewHoughPoint = true) {
                            // add it to the Matrix
                            AccumulatorMatrix.add(new HoughPoint(rho,theta));
                        }
                        isNewHoughPoint = true;
                    }
                }
                }
            }
            
            
            ArrayList<Point> points = new ArrayList<Point>();
            
            // add all of the Hough Points to graph in xy space
            for (HoughPoint hp : AccumulatorMatrix) {
                if (hp.getValue() > 2) {
                    double xy[] = MyMath.polToRect(hp.getRho(), hp.getTheta());
                    System.out.println("(" + hp.getRho() + "," + hp.getTheta() + ")" + "\tValue: " + hp.getValue());
                    // multiply x by 2 to stretch the graph horizontally
                    points.add(new Point(xy[0]*2,xy[1]));
                }
                    
            }
            
            
            frame.setSize(1600,800);
            frame.setLayout(new GridLayout(2,0));
            jpLine panel = new jpLine(new ArrayList(), points);
            panel.setPreferredSize(new Dimension(origImage.getWidth(), origImage.getHeight()));
            frame.add(new JLabel(new ImageIcon(origImage)));
            //frame.add(new JLabel(new ImageIcon(threshImage)));
            frame.add(new JLabel(new ImageIcon(edgedImage)));
            frame.add(panel);
            frame.setVisible(true);
            
            /**/
            
            
            
            // @va Dowd
            
        }
    
    
    
    

    
    
    

  }
