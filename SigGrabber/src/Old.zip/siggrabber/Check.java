package siggrabber;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Check {
    private String type;
    private BufferedImage image;
    
    public Check() {
        type = this.getType();
    };
    
    public Check(BufferedImage image) {
        this.image = image;
        type =  this.getType();
    }
    
    final public String getType() {
        ArrayList horizLines = LineTools.getHorizLines(image);
        ArrayList vertLines = LineTools.getVertLines(image);
        
        if (isTravellersCheck(horizLines, vertLines)) {
            return "Travellers";
        }
        else if (isStandCheck(horizLines, vertLines)) {
            return "Standard Check";
        }
        return "Unknown";
    }
    
    public boolean isTravellersCheck(ArrayList<Line> horizLines, ArrayList<Line> vertLines) {
        
        
                
        return true;
    }
    private boolean isStandCheck(ArrayList<Line> horizLines, ArrayList<Line> vertLines) {
        int numOfLongHorizLines = 0;
        int longHorizLineThreshold = image.getWidth() - (int)(image.getWidth() * .20);
        int numOfLongVertLines = 0;
        int longVertLineThreshold = image.getHeight() - (int)(image.getHeight() * .20);
        
        if (horizLines != null && vertLines != null) {
            // for each horizontal line 
            for (Line line : horizLines) {
                // if there was two horiz lines longer than the threshold
                if (line.getLength() >= longHorizLineThreshold) {
                    numOfLongHorizLines++;
                }
            }

            // for each Vert line 
            for (Line line : vertLines) {
                // if there was two horiz lines longer than the threshold
                if (line.getLength() >= longVertLineThreshold) {
                    numOfLongVertLines++;
                }
            }

            // if there are two horiz and vert lines that exceed the thresholds they are probably 
            // the border of a standard check
            if (numOfLongHorizLines == 2 && numOfLongVertLines == 2) {
                return true;
            }
        }
        return false;
    } 
    
}


