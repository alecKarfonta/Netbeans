package siggrabber;


public class HoughPoint {
    private double rho;
    private int theta;
    private int value;
    
    public HoughPoint() {
        this(0,0);
    }
    public HoughPoint(double rho, int theta) {
        this.rho = rho;
        this.theta = theta;
    }

    public double getRho() {
        return rho;
    }

    public int getTheta() {
        return theta;
    }

    public int getValue() {
        return value;
    }

    public void setRho(double rho) {
        this.rho = rho;
    }

    public void setTheta(int theta) {
        this.theta = theta;
    }
    
    public void incrementValue() {
        this.value++;
    }
    
}
