
package siggrabber;

public class Point {
    private double x, y;
    public Point() {
        this(0,0);
    }
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
    
    @Override
    public String toString() {
        return ("(" + this.x + " , " + this.y + ")");
    }
    
}
