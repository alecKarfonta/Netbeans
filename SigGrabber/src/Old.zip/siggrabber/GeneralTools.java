
package siggrabber;

import java.awt.FlowLayout;
import java.io.File;
import javax.swing.JFrame;

public class GeneralTools {
    public static JFrame createFrame(String title) {
        JFrame frame = new JFrame();
        frame.setTitle(title);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1800, 900);
        return frame;        
    }
    
    public static String[] getFileNames(String folderName) {
        return new File(folderName).list();
    }
}
