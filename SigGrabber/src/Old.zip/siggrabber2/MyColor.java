package siggrabber2;

import java.util.Comparator;

public class MyColor {
    private int count;
    private int color;
    
    public MyColor() {
        
    }
    
    public MyColor(int color) {
        this.color = color;
        this.count = 1;
    }

    public int getCount() {
        return count;
    }

    public int getColor() {
        return color;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setColor(int color) {
        this.color = color;
    }
    
    public void increment() {
        count++;
    }
    
    public static class compCounts implements Comparator<MyColor> {

        @Override
        public int compare(MyColor color1, MyColor color2) {
            int colorDiff = color1.getColor() - color2.getColor();
            
            if (colorDiff == 0) {
                return 0;
            } else if (colorDiff > 0) {
                return 1;
            } else if (colorDiff < 0) {
                return -1;
            }
            return 1;
        }
        
    }

}
