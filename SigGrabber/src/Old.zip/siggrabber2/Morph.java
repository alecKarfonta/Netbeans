/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package siggrabber2;

import Jama.Matrix;
import java.awt.geom.AffineTransform;
import java.awt.image.*;
import java.awt.Graphics2D;
import java.awt.Polygon;

public class Morph {
   
    public static BufferedImage morph(
            BufferedImage srcImg, BufferedImage objImg, Polygon p) 
    {        
        // Image to store the result
        BufferedImage outImg = new BufferedImage(
            objImg.getWidth(), 
            objImg.getHeight(), 
            BufferedImage.TYPE_INT_RGB
        );
       
       // Paint objImg on dstImg first
       Graphics2D g = (Graphics2D) outImg.getGraphics();
       g.drawImage(objImg, 0, 0, null);   
       
       // Triangulate the rectangle or 4-sided polygon into 2 triangles
        int w = srcImg.getWidth();
        int h = srcImg.getHeight();
        
        // Triangulate the quadrilateral (4-sided polygon) into two triangles
        Polygon srcT[] = new Polygon[2], dstT[] = new Polygon[2];
        
        srcT[0] = createTriangle(0, 0, w-1, 0, 0, h-1);
        srcT[1] = createTriangle(w-1, h-1, 0, h-1, w-1, 0);
                      
        dstT[0] = createTriangle(p.xpoints[0], p.ypoints[0],
                                 p.xpoints[1], p.ypoints[1],
                                 p.xpoints[3], p.ypoints[3]);
        
        dstT[1] = createTriangle(p.xpoints[2], p.ypoints[2],
                                 p.xpoints[3], p.ypoints[3],
                                 p.xpoints[1], p.ypoints[1]);        
        
        
        
        morph(srcImg, outImg, srcT, dstT);
        
        return outImg;
    }
    
    // Morph the pixels in "src" to "dst" according to the triangles
    // specified in srcT[] and dstT[] (each of the polygon in srcT[] and
    // dstT[] represents a triangle.)
    public static void morph(
        BufferedImage src, BufferedImage dst,
        Polygon srcT[], Polygon dstT[]
    ) {
        for (int i = 0; i < srcT.length; i++) {
            AffineTransform tx = computeTransform(srcT[i], dstT[i]);
                       
            AffineTransformOp txOp = 
                new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
            
            BufferedImage tmpImg = 
                new BufferedImage(400, 300, src.getType());
            
            txOp.filter(src, tmpImg);
                
            Graphics2D g = (Graphics2D)dst.getGraphics();
            g.setClip(dstT[i]);
            g.drawImage(tmpImg, 0, 0, null);
        }
    }

   // Find the linear transformation matrix that transform the triangle "src" 
   // to triangle "dst".
    static AffineTransform computeTransform(Polygon src, Polygon dst) {
        double coef[][] = 
            {{src.xpoints[0], src.ypoints[0], 1}, 
             {src.xpoints[1], src.ypoints[1], 1}, 
             {src.xpoints[2], src.ypoints[2], 1}};
        
        double rhsx[][] = {{dst.xpoints[0]}, {dst.xpoints[1]}, {dst.xpoints[2]}};
        double rhsy[][] = {{dst.ypoints[0]}, {dst.ypoints[1]}, {dst.ypoints[2]}};
        
        Matrix A = new Matrix(coef);
        Matrix rhs1 = new Matrix(rhsx);
        Matrix rhs2 = new Matrix(rhsy);
        
        Matrix lhs1 = A.solve(rhs1);
        Matrix lhs2 = A.solve(rhs2);
               
        double m00 = lhs1.get(0, 0);
        double m01 = lhs1.get(1, 0);
        double m02 = lhs1.get(2, 0);
        
        double m10 = lhs2.get(0, 0);
        double m11 = lhs2.get(1, 0);
        double m12 = lhs2.get(2, 0);
        
        return new AffineTransform(m00, m10, m01, m11, m02, m12);
    }
    
    public static Polygon createTriangle(
            int x1, int y1, int x2, int y2, int x3, int y3
    ) {
        Polygon p = new Polygon();   
        p.addPoint(x1, y1);
        p.addPoint(x2, y2);
        p.addPoint(x3, y3);
        return p;
    }
} // End of class

