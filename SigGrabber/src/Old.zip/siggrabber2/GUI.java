
package siggrabber2;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.Histogram;
import javax.swing.JFileChooser;

public class GUI extends javax.swing.JFrame {

    
    private File fCheck = null;
    private File fStockCheck = new File("images/trav0.jpg");
    
    private BufferedImage biCheck;
    private BufferedImage biStockCheckGray;
    private BufferedImage biCheckScaled;
    private BufferedImage biEdges;
    private BufferedImage biStockCheck;
    private BufferedImage biStockCheckScaled;
    private Histogram histogram;
    
    private boolean isMatch = false;
    
    public GUI() {
        initComponents();
        // open the stock check image
        try {
            biStockCheck = ImageIO.read(fStockCheck);
            // check if the image is too big for the label
            if (biStockCheck.getWidth() > jlOutput.getWidth()
                    || biStockCheck.getHeight() > jlOutput.getHeight()) {
                // create a new scaled image 
                biStockCheckScaled = ImageTools.resizeImage(biStockCheck, 
                        jlOutput.getWidth(), 
                        jlOutput.getHeight(), true);
                // display the scaled image
                jlOutput.setIcon(new ImageIcon(biStockCheckScaled));
            // else the image did not need to be scaled
            } else {
                jlOutput.setIcon(new ImageIcon(biStockCheck));
            }
            jtaTargetInfo.append("Aspect Ratio: " + ImageTools.getAspectRatio(biStockCheck) + "\n");
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fileChooser = new javax.swing.JFileChooser();
        jpCheckImage = new javax.swing.JPanel();
        jlInput = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jpCheckControl = new javax.swing.JPanel();
        jbHistogram = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtaTargetInfo = new javax.swing.JTextArea();
        jbOpenCheck = new javax.swing.JButton();
        jbMorph = new javax.swing.JButton();
        jbCompare = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaSourceInfo = new javax.swing.JTextArea();
        jbDetectLines1 = new javax.swing.JButton();
        jpCheckLines = new javax.swing.JPanel();
        jlOutput = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jmiOpenCheck = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpCheckImage.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setText("Source Image");

        org.jdesktop.layout.GroupLayout jpCheckImageLayout = new org.jdesktop.layout.GroupLayout(jpCheckImage);
        jpCheckImage.setLayout(jpCheckImageLayout);
        jpCheckImageLayout.setHorizontalGroup(
            jpCheckImageLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jpCheckImageLayout.createSequentialGroup()
                .addContainerGap()
                .add(jlInput, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .add(jpCheckImageLayout.createSequentialGroup()
                .add(332, 332, 332)
                .add(jLabel2)
                .addContainerGap(289, Short.MAX_VALUE))
        );
        jpCheckImageLayout.setVerticalGroup(
            jpCheckImageLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jpCheckImageLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jLabel2)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jlInput, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 329, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jpCheckControl.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jbHistogram.setText("Histogram");
        jbHistogram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbHistogramActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel1.setText("Image Info:");

        jtaTargetInfo.setColumns(20);
        jtaTargetInfo.setRows(5);
        jScrollPane1.setViewportView(jtaTargetInfo);

        jbOpenCheck.setText("Open Check");
        jbOpenCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbOpenCheckActionPerformed(evt);
            }
        });

        jbMorph.setText("Morph");
        jbMorph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbMorphActionPerformed(evt);
            }
        });

        jbCompare.setText("Compare");
        jbCompare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCompareActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel4.setText("Image Info:");

        jtaSourceInfo.setColumns(20);
        jtaSourceInfo.setRows(5);
        jScrollPane2.setViewportView(jtaSourceInfo);

        jbDetectLines1.setText("Detect Lines");
        jbDetectLines1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbDetectLines1ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jpCheckControlLayout = new org.jdesktop.layout.GroupLayout(jpCheckControl);
        jpCheckControl.setLayout(jpCheckControlLayout);
        jpCheckControlLayout.setHorizontalGroup(
            jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jpCheckControlLayout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel4)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(199, 199, 199)
                .add(jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jpCheckControlLayout.createSequentialGroup()
                        .add(jbOpenCheck, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 316, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .add(jpCheckControlLayout.createSequentialGroup()
                        .add(jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jbMorph, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 316, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jbCompare, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 316, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jbDetectLines1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 316, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jbHistogram, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 316, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(631, 631, 631))))
        );
        jpCheckControlLayout.setVerticalGroup(
            jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jpCheckControlLayout.createSequentialGroup()
                .addContainerGap()
                .add(jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane1)
                    .add(jScrollPane2)
                    .add(jpCheckControlLayout.createSequentialGroup()
                        .add(jpCheckControlLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jpCheckControlLayout.createSequentialGroup()
                                .add(jbOpenCheck, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jbMorph, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jbCompare, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jLabel1)
                            .add(jLabel4))
                        .add(4, 4, 4)
                        .add(jbDetectLines1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jbHistogram, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jpCheckLines.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setText("Target Image");

        org.jdesktop.layout.GroupLayout jpCheckLinesLayout = new org.jdesktop.layout.GroupLayout(jpCheckLines);
        jpCheckLines.setLayout(jpCheckLinesLayout);
        jpCheckLinesLayout.setHorizontalGroup(
            jpCheckLinesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jpCheckLinesLayout.createSequentialGroup()
                .addContainerGap()
                .add(jlOutput, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
                .add(80, 80, 80))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jpCheckLinesLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jLabel3)
                .add(307, 307, 307))
        );
        jpCheckLinesLayout.setVerticalGroup(
            jpCheckLinesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jpCheckLinesLayout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel3)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jlOutput, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addContainerGap())
        );

        jMenu1.setText("File");

        jmiOpenCheck.setText("Open Check");
        jmiOpenCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiOpenCheckActionPerformed(evt);
            }
        });
        jMenu1.add(jmiOpenCheck);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jpCheckControl, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(layout.createSequentialGroup()
                        .add(jpCheckImage, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jpCheckLines, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jpCheckImage, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jpCheckLines, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jpCheckControl, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        layout.linkSize(new java.awt.Component[] {jpCheckImage, jpCheckLines}, org.jdesktop.layout.GroupLayout.VERTICAL);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jmiOpenCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiOpenCheckActionPerformed
        openCheck();
    }//GEN-LAST:event_jmiOpenCheckActionPerformed

    private void jbHistogramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbHistogramActionPerformed
        
        biStockCheckGray = ImageTools.getGrayscale(biStockCheck);
        jlOutput.setIcon(
                new ImageIcon(
                    ImageTools.resizeImage(
                        biStockCheckGray, jlOutput.getWidth(), 
                        jlOutput.getHeight(), true)));
        ArrayList<MyColor> colorCounts = ImageTools.getHistogramVertical(biStockCheckGray, 700, 0, 2);
        
        // sort
        //Collections.sort(colorCounts, new MyColor.compCounts());
        for (MyColor color : colorCounts) {
            jtaTargetInfo.append("Color: " + color.getColor() + " Count: " + color.getCount());
        }
    }//GEN-LAST:event_jbHistogramActionPerformed

    public static void sort(ArrayList<MyColor> colorCounts) {
            
        }
    
    private void jbOpenCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbOpenCheckActionPerformed
        openCheck();
    }//GEN-LAST:event_jbOpenCheckActionPerformed

    private void jbMorphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbMorphActionPerformed
        try {
            BufferedImage morphedImage;
            biStockCheck = ImageIO.read(fStockCheck);
            if (fCheck == null) {
                openCheck();
            }
                    
            isMatch = CheckTools.isCheckMatch(biCheck, biStockCheck);
            jtaTargetInfo.append("isMatch: " + isMatch + "\n");
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbMorphActionPerformed

    private void jbCompareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCompareActionPerformed
        if (biCheck == null) {
            openCheck();
        }
        isMatch = CheckTools.isCheckMatch(biCheck, biStockCheck);
        jtaTargetInfo.append("isMatch: " + isMatch + "\n");
    }//GEN-LAST:event_jbCompareActionPerformed

    private void jbDetectLines1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbDetectLines1ActionPerformed
        if (fCheck == null) {
            openCheck();
        }
        //create the detector
        LineDetector detector = new LineDetector();
        //adjust its parameters as desired
        detector.setLowThreshold(0.5f);
        detector.setHighThreshold(3f);
        //apply it to an image
        detector.setSourceImage(biCheck);
        detector.process();
        BufferedImage edges = detector.getEdgesImage();
        jlOutput.setIcon(new ImageIcon(edges));
    }//GEN-LAST:event_jbDetectLines1ActionPerformed

    public void openCheck() {
        try {
            int returnVal = fileChooser.showOpenDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                fCheck = fileChooser.getSelectedFile();
            } else {
                System.out.println("File access cancelled by user.");
            }
            if (fCheck.getName().contains(".jpg")) {
                biCheck = ImageIO.read(fCheck);
                
                // check if the image is too big for the label
                if (biCheck.getWidth() > jlInput.getWidth()
                        || biCheck.getHeight() > jlInput.getHeight()) {
                    // create a new scaled image 
                    biCheckScaled = ImageTools.resizeImage(biCheck, 
                            jlInput.getWidth(), 
                            jlInput.getHeight(), true);
                    // display the scaled image
                    jlInput.setIcon(new ImageIcon(biCheckScaled));
                // else the image did not need to be scaled
                } else {
                    jlInput.setIcon(new ImageIcon(biCheck));
                }
                // get the aspect ratio on the actual image, not the scaled version
                jtaSourceInfo.append("Aspect Ratio: " + ImageTools.getAspectRatio(biCheck) + "\n");
            } else {
                System.out.println("File was not an image");
            }
            
            
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFileChooser fileChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbCompare;
    private javax.swing.JButton jbDetectLines1;
    private javax.swing.JButton jbHistogram;
    private javax.swing.JButton jbMorph;
    private javax.swing.JButton jbOpenCheck;
    private javax.swing.JLabel jlInput;
    private javax.swing.JLabel jlOutput;
    private javax.swing.JMenuItem jmiOpenCheck;
    private javax.swing.JPanel jpCheckControl;
    private javax.swing.JPanel jpCheckImage;
    private javax.swing.JPanel jpCheckLines;
    private javax.swing.JTextArea jtaSourceInfo;
    private javax.swing.JTextArea jtaTargetInfo;
    // End of variables declaration//GEN-END:variables
}
