package siggrabber2;

import java.awt.Polygon;
import java.awt.image.BufferedImage;
import javax.media.jai.Histogram;

public class CheckTools {
    
    private boolean logging = true;
    private int longMorphTime = 15;
    
    public static boolean isCheckMatch(BufferedImage check1, BufferedImage check2) {
        if (isAspectRatioMatch(check1, check2)) {
            if (isMorphTimeLow(check1, check2)) {
                return true;
            }
        } 
        return false;
    }
    
    public static boolean isAspectRatioMatch(BufferedImage check1, BufferedImage check2) {
        double aspectRatio1 = check1.getWidth() / check2.getHeight();
        double aspectRatio2 = check2.getWidth() / check2.getHeight();
        
        // if the first aspect ratio is greater than the second
        if (aspectRatio1 > aspectRatio2) {
            // if the first aspect ratio is more than 10% greater than the second aspect ratio 
            if ((aspectRatio1 - aspectRatio2) > (aspectRatio1 * .1)) {
                System.out.println("Not a match: Aspect Ratio off");
                return false;
            }
        // else the second aspect ratio is greater
        } else {
            // if the second aspect ratio is more than 10% greater than the first
        }   if ((aspectRatio2 - aspectRatio1) > (aspectRatio1 * .1)) {
            System.out.println("Not a match: Aspect Ratio off");
            return false;
        }
        
        return true;
    }
    
    public static boolean isMorphTimeLow(BufferedImage biCheck, BufferedImage biStockCheck) {
        // define the polygoin to morph
        Polygon poly = new Polygon();
        poly.addPoint(0, 0);
        poly.addPoint(biCheck.getWidth(), 0);
        poly.addPoint(biCheck.getWidth(), biCheck.getHeight());
        poly.addPoint(0, biCheck.getHeight());

        // morph the image
        long startTime = System.currentTimeMillis();
        BufferedImage morphedImage = Morph.morph(biCheck, biStockCheck, poly);
        long endTime = System.currentTimeMillis();
        long morphTime = endTime - startTime;
        System.out.println("MorphTime:" + morphTime);
        System.out.println("Morph Image dim: " + morphedImage.getWidth() + "x" + morphedImage.getHeight());
        if (morphTime > 6 && morphTime < 16) {
            return true;
        }
        return false;
    }
}
